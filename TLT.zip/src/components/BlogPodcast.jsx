import { ArrowRight, Box } from 'lucide-react';
import React from 'react'
import { Link } from 'react-router-dom';
import cards from './api/blog.json'


const BlogPodcast = () => {
    return (
        <div className="flex mt-10 bg-white text-black justify-center items-center">
            <div className="container">
                <div className=" w-fit flex justify-center items-center gap-2 px-4 py-1 border-b border-gray-400 mx-auto">
                    <Box strokeWidth={1.5} size={19} />
                    <h1>Blog / Podcast</h1>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 px-2 pt-6 md:px-6">

                    {cards.map((card, index) => (
                        <Link to={`/blog/${card.slug}`} key={index} className=" border border-gray-400 hover:cursor-pointer group p-4 md:p-6 bg-white text-black rounded-2xl shadow-md transition-all transform hover:scale-101 hover:shadow-lg">
                            <img src={card.image} alt={card.title} className=" border border-gray-400 mb-4 w-full h-40 object-cover rounded-lg" />
                            <h2 className="text-xl font-semibold">{card.title}</h2>
                            <p className="text-gray-700 mt-2 text-ellipsis line-clamp-2 ">{card.description}</p>
                            <div className=" mt-4 flex justify-start items-center gap-2 group-hover:underline ">
                                <button href="#" className=" font-medium ">
                                    {card.linkText}
                                </button>
                                <ArrowRight strokeWidth={2} size={18} />
                            </div>
                        </Link>
                    ))}
                </div>
            </div>
        </div>
    )
}

export default BlogPodcast
