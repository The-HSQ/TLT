import { Facebook, Instagram, Linkedin, Twitter, Youtube } from 'lucide-react'
import React from 'react'
import { Link } from 'react-router-dom'

const Footer = () => {
    return (
        <footer className=' bg-[#1C1C1C] text-white flex justify-center items-center px-5 py-4 ' >
            <div className="container flex flex-col md:flex-col md:justify-between md:items-center gap-4 ">
                {/* Top Side */}
                <div className=" w-full flex flex-col md:flex-row gap-10 py-6 ">
                    {/* Left */}
                    <div className=" w-full md:w-[50%] flex flex-col justify-start items-start gap-1 ">
                        <Link to='/' className=" cursor-pointer text-6xl font-bold ">
                            TLT
                        </Link>

                        <Link
                            to="/signup"
                            className=" flex justify-center text-sm items-center gap-2 border border-gray-400 px-6 py-2 rounded-full cursor-pointer transition-all duration-300 ease-in-out hover:translate-y-0.5 font-semibold"
                        >
                            Sign Up to get started
                        </Link>
                    </div>

                    {/* Right */}
                    <div className=" w-full md:w-[50%] pr-3 flex flex-col md:flex-row gap-8 justify-between text-sm">
                        {/* Features */}
                        <div>
                            <h3 className="text-lg font-bold mb-4">FEATURES</h3>
                            <ul className="space-y-2 text-gray-400">
                                <li>On Premise</li>
                                <li>Chat Support</li>
                                <li>Agents</li>
                                <li>Knowledge Base</li>
                            </ul>
                        </div>

                        {/* Resources */}
                        <div>
                            <h3 className="text-lg font-bold mb-4">RESOURCES</h3>
                            <ul className="space-y-2 text-gray-400">
                                <li>Blog</li>
                                <li>Guides</li>
                                <li>APIs</li>
                                <li>FAQ</li>
                            </ul>
                        </div>

                        {/* Company */}
                        <div>
                            <h3 className="text-lg font-bold mb-4">COMPANY</h3>
                            <ul className="space-y-2 text-gray-400">
                                <li>Home</li>
                                <li>Privacy Policy</li>
                                <li>Terms of Service</li>
                                <li>Cookie Policy</li>
                                <li>Contact Us</li>
                            </ul>
                        </div>
                    </div>
                </div>

                {/* line */}
                <div className=" w-[96%] h-[1px] bg-gray-400 "></div>

                {/* Bottom Side */}
                <div className=" flex flex-col md:flex-row gap-4 w-full py-6 ">
                    {/* Right Side */}
                    <div className=" w-full md:w-[50%] flex justify-start ">
                        <p className=' text-sm text-gray-400 ' >&copy; 2024 Copyright One Realm, Inc</p>
                    </div>

                    {/* Left Side */}
                    <div className=" w-full md:w-[50%] flex md:justify-end gap-4 text-gray-400 ">
                        <Facebook size={22} />
                        <Instagram size={22} />
                        <Twitter size={22} />
                        <Linkedin size={22} />
                        <Youtube size={22} />
                    </div>
                </div>
            </div>
        </footer >
    )
}

export default Footer
