import { ChevronRight, Home } from 'lucide-react'
import React from 'react'
import { Link } from 'react-router-dom'

const BlogDetails = () => {
  return (
    <div className=' flex justify-center ' >
      <div className="container flex flex-col gap-4 md:gap-6 items-center justify-center py-7 md:py-10 ">
        <div className=" w-full lg:w-[70%] text-black px-3 flex gap-4 md:gap-6 flex-col justify-center items-start md:items-center ">
          {/* home and blog icons */}
          <div className=' flex gap-3 justify-center items-center text-[#979591] '>
            <Link to='/' >
              <Home className=' hover:cursor-pointer hover:text-black ' size={22} />
            </Link>

            <ChevronRight size={20} />

            <Link to='/blog' >
              <span className=' text-[13px] hover:cursor-pointer hover:text-black '>Blog</span>
            </Link>
          </div>
          {/* heading */}
          <h1 className=' md:text-center text-3xl md:text-4xl text-balance font-semibold ' >Jasper Named a 2025 NRF Innovator at Retail’s Big Show</h1>
          {/* slug description */}
          <p className=' md:text-center text-sm text-balance text-gray-800  ' >The Innovators Showcase at NRF 2025: Retail’s Big Show recognizes the top 50 tech leaders shaping the future of retail.</p>
          {/* publish and author name */}
          <div className=' flex flex-col md:flex-row gap-2 md:gap-5 md:text-center text-[13px] text-balance text-gray-400 '>
            <p>Published on Dec 12, 2024</p>
            <p>By The TLT Marketing Team</p>
          </div>
          {/* image */}
          <img className=' w-full rounded-3xl ' src="./../blog/blog_1.jpeg" alt="" />
          {/* line */}
          <div className=" w-full h-[1px] bg-gray-300 "></div>
          {/* description */}
          <div className=" flex flex-col gap-4 ">
            <p>We’re thrilled to share that Jasper has been chosen to participate in the exclusive Innovators Showcase at NRF 2025: Retail’s Big Show, featuring us as one of the most groundbreaking technology companies shaping the future of retail. This recognition cements Jasper’s position as a leader in retail marketing and furthers our mission to elevate all marketing and all marketers with AI.</p>
            <p>
              "Being named an NRF 2025 Innovator is an incredible milestone that underscores our vision for a bold, AI-powered future in marketing," said Loreal Lynch, CMO of Jasper. "At Jasper, we’re committed to empowering retail and e-commerce businesses—including customers like Wayfair, Ulta Beauty, and Anthropologie—to deliver personalization at scale, enhance customer experiences, drive measurable ROI, and accelerate their go-to-market strategies. This recognition highlights the value we bring to retail marketing teams, equipping them to adapt to rapidly evolving consumer behaviors.”</p>
            <p>
              The Innovators Showcase at NRF 2025: Retail’s Big Show brings together the top 50 retail trailblazers, including Jasper, chosen for their groundbreaking impact on the industry. More than just an exhibition, this program highlights the most transformative technologies shaping the future of retail.
            </p>
            <p>
              As the leading global event for the retail industry, NRF 2025 will gather thousands of professionals, innovators, and thought leaders at the Javits Center in New York City from January 12–14, 2025. Jasper is honored to be part of this prestigious program, where we’ll showcase our latest innovations and demonstrate how our enterprise retail customers harness AI to drive business transformation, elevate customer experiences, and achieve measurable results.
            </p>
            <p>
              Are you going to NRF 2025? Let us know or say hello to our team at booth #8226 located on Level 4 in the Innovators Showcase!
            </p>
          </div>
        </div>
        {/* line */}
        <div className=" w-full h-[1px] bg-gray-300 "></div>
        {/* More blog */}
        
      </div>
    </div>
  )
}

export default BlogDetails
