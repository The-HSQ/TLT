import React from 'react'
import BlogPodcast from '../components/BlogPodcast'

const Blog = () => {
  return (
    <>
      <div className=' mb-10 ' >
        <BlogPodcast />
      </div>
    </>
  )
}

export default Blog
